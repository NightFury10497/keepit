# -*- coding: utf-8 -*-
"""
Created on Wed Jun 14 17:03:32 2023

@author: Automation.Finance
"""

import os

def change_file_extension(folder_path, old_extension, new_extension):
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.endswith(old_extension):
                old_file_path = os.path.join(root, file)
                new_file_path = os.path.join(root, file.replace(old_extension, new_extension))
                os.rename(old_file_path, new_file_path)

# Usage example
folder_path = r"C:\Users\AZ318TQ\OneDrive - EY\Desktop\New folder\fastapilearn\app development eneos\\ "
old_extension = '.txt'
new_extension = '.py'

change_file_extension(folder_path, old_extension, new_extension)
