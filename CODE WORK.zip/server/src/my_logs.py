# -*- coding: utf-8 -*-
"""
Created on Mon Jun 26 15:11:37 2023

@author: AZ318TQ
"""

import logging


class ColoredLogs:
    def __init__(self, log_file):
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)

        # Create a file handler and set the log level
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)

        # Create a console handler and set the log level
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)

        # Define the log format
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

        # Add the formatter to the handlers
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Add the handlers to the logger
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)

    def log_info(self, message):
        self.logger.info('\033[92m' + message + '\033[0m')

    def log_warning(self, message):
        self.logger.warning('\033[93m' + message + '\033[0m')
    def log_error(self, message):
        self.logger.error('\033[91m' + message + '\033[0m')
    def log_debug(self, message):
        self.logger.debug('\033[92m' + message + '\033[0m')
