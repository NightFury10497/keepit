# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 15:47:40 2023

@author: Automation.Finance
"""

from OpenSSL import crypto

def asd(pfx_file,pfx_password,crt_file,key_file):
    data = open(pfx_file,'rb').read()
    pfx = crypto.load_pkcs12(data,pfx_file)
    
    
    cert = crypto.dump_certificate(crypto.FILETYPE_PEM, pfx.get_certificate())
    key = crypto.dump_privatekey(crypto.FILETYPE_PEM, pfx.get_key())
    return cert,key

pfx_file = r"C:\Users\fa.software\Downloads\AZURE VPN\ENEOSCLIENT.pfx" 
pfx_password = "12345"
crt_file = ''
key_file = ''
asd(pfx_file,pfx_password,crt_file,key_file)

    
    