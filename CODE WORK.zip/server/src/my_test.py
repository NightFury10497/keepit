# -*- coding: utf-8 -*-
"""
Created on Mon Jun 26 15:21:01 2023

@author: AZ318TQ
"""

import time


time.sleep(15)

# print(stop)
print("Done")