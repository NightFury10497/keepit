# -*- coding: utf-8 -*-
"""
Created on Mon Jun 12 17:47:53 2023

@author: Automation.Finance
"""

import os
import sys
import json
import requests
import http.client
import configparser
import pandas as pd

def call_config_file(var):
    config_file_path = os.path.join(os.getcwd(),var,"Config","config.ini")
    return config_file_path

def read_config_file(file_path):
    config = configparser.ConfigParser()
    config.read(file_path)
    
    return config

def getConfigValue(var,key_name):    
    # ''' To call any value from anywhere  # getConfigValue('apiport') '''    
    config = read_config_file(call_config_file(var))
    section_name = 'SECTION1' # default setup
    value = config.get(section_name, key_name)    
    
    return value




def read_keys_from_our_excel():
    a = getConfigValue('server','applicationfolder')
    b = getConfigValue('server','accesstoken')
    secret_file = a+b
    print('secret_file',secret_file)
    
    # file = r"C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx"
    df = pd.read_excel(secret_file)
    df.columns
    my_secret_keys = list(df['Generated key'])
    return my_secret_keys
















def return_access_token():
    conn = http.client.HTTPSConnection("login.microsoftonline.com")
    payload = 'grant_type=client_credentials&client_id=840bc398-98e6-46ff-a729-1b912550d557&client_secret=B.C8Q~B0X-rhgShheuhTi6Onk7R.JMHCxxCAaa4X&resource=https%3A%2F%2Fgraph.microsoft.com%2F'
    headers = {
      'Content-Type': 'application/x-www-form-urlencoded'
    #  'Cookie': 'fpc=AvX8v3BghHZFkf2t583I82gqXdhlAQAAAN9cCtwOAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd'
    }
    conn.request("POST", "/dd655549-a56d-485e-b09c-a5eb11419b79/oauth2/token", payload, headers)
    res = conn.getresponse()
    data = res.read()
    data = json.loads(data)
    access_token = data['access_token']
    return access_token


def sharepoint_site_checker(site_name,access_token):
    
    conn = http.client.HTTPSConnection("graph.microsoft.com")
    site_name = site_name
    payload = ''
    headers = {
      'Authorization': 'Bearer ' + access_token
    }
    conn.request("GET", "/v1.0/sites?search="+site_name, payload, headers)
    res = conn.getresponse()
    data = res.read()
    data = json.loads(data)
    site_id = data['value'][0]['id']
    return site_id


def download_file(api_endpoint,site_id, item_id, file_path, access_token):
    url = f'{api_endpoint}/sites/{site_id}/drive/items/{item_id}/content'
    headers = {
        'Authorization': f'Bearer {access_token}',
    }
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    with open(file_path, 'wb') as file:
        file.write(response.content)

# Function to create a local folder
def create_local_folder(folder_path):
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

# Function to recursively download folder structure
def download_folder_structure(api_endpoint,site_id, folder_id, target_folder_path, access_token):
    create_local_folder(target_folder_path)

    url = f'{api_endpoint}/sites/{site_id}/drive/items/{folder_id}/children'
    headers = {
        'Authorization': f'Bearer {access_token}',
    }
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    items = response.json().get('value', [])

    for item in items:
        item_name = item['name']
        item_id = item['id']
        item_type = item['folder']['childCount'] > 0 if 'folder' in item else False

        if item_type:
            new_target_folder_path = os.path.join(target_folder_path, item_name)
            download_folder_structure(api_endpoint,site_id, item_id, new_target_folder_path, access_token)
        else:
            file_path = os.path.join(target_folder_path, item_name)
            download_file(api_endpoint,site_id, item_id, file_path, access_token)

# Main function
def download_previous_input_folder(api_endpoint,site_id,access_token,target_folder_path):
    # SharePoint site ID or path
    site_id = site_id

    # Source folder ID in SharePoint
    folder_id = 'root'

    # Local target folder path
    target_folder_path = target_folder_path
    
    # Access token (obtained through authentication)

    # Download folder structure from SharePoint
    download_folder_structure(api_endpoint,site_id, folder_id, target_folder_path, access_token)




#############################################################################################
# Function to download a file from SharePoint
def download_file_temp(api_endpoint,site_id, item_id, file_path, access_token):
    url = f'{api_endpoint}/sites/{site_id}/drive/items/{item_id}/content'
    headers = {
        'Authorization': f'Bearer {access_token}',
    }
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    with open(file_path, 'wb') as file:
        file.write(response.content)

# Function to create a local folder
def create_local_folder_temp(folder_path):
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

# Function to recursively download folder structure
def download_folder_structure_temp(api_endpoint,site_id, folder_id, target_folder_path, access_token):
    create_local_folder(target_folder_path)

    url = f'{api_endpoint}/sites/{site_id}/drive/items/{folder_id}/children'
    headers = {
        'Authorization': f'Bearer {access_token}',
    }
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    items = response.json().get('value', [])

    for item in items:
        item_name = item['name']
        item_id = item['id']
        item_type = item['folder']['childCount'] > 0 if 'folder' in item else False

        if item_type:
            new_target_folder_path = os.path.join(target_folder_path, item_name)
            download_folder_structure_temp(api_endpoint,site_id, item_id, new_target_folder_path, access_token)
        else:
            file_path = os.path.join(target_folder_path, item_name)
            download_file_temp(api_endpoint,site_id, item_id, file_path, access_token)

# Main function
def download_temp_latest_uploaded_files(api_endpoint,site_id,access_token,target_folder_path):
    # SharePoint site ID or path
    site_id = site_id

    # Source folder ID in SharePoint
    folder_id = 'root'

    # Local target folder path
    target_folder_path = target_folder_path

    # Access token (obtained through authentication)

    # Download folder structure from SharePoint
    download_folder_structure_temp(api_endpoint,site_id, folder_id, target_folder_path, access_token)





#########################################################
#       upload files back to sharepoint
#########################################################



# Function to create a folder in SharePoint
def create_folder_again_on_sharepoint(api_endpoint,site_id, parent_folder_id, folder_name, access_token):
    url = f'{api_endpoint}/sites/{site_id}/drive/items/{parent_folder_id}/children'
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    payload = {
        'name': folder_name,
        'folder': {},
        '@microsoft.graph.conflictBehavior': 'rename'
    }
    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()
    return response.json()['id']

# Function to upload a file to SharePoint
def upload_file_back_to_sharepoint(api_endpoint,site_id, parent_folder_id, file_path, access_token):
    url = f'{api_endpoint}/sites/{site_id}/drive/items/{parent_folder_id}:/{os.path.basename(file_path)}:/content'
    headers = {
        'Authorization': f'Bearer {access_token}',
    }
    with open(file_path, 'rb') as file:
        response = requests.put(url, headers=headers, data=file)
        response.raise_for_status()

# Function to copy folder structure recursively
def copy_folder_structure_to_sharepoint(api_endpoint,site_id, parent_folder_id, source_folder_path, access_token):
    folder_name = os.path.basename(source_folder_path)
    new_folder_id = create_folder_again_on_sharepoint(api_endpoint,site_id, parent_folder_id, folder_name, access_token)
    
    for item in os.listdir(source_folder_path):
        item_path = os.path.join(source_folder_path, item)
        if os.path.isdir(item_path):
            copy_folder_structure_to_sharepoint(api_endpoint,site_id, new_folder_id, item_path, access_token)
        else:
            upload_file_back_to_sharepoint(api_endpoint,site_id, new_folder_id, item_path, access_token)

# Main function
def push_new_folder_to_sharepoint(api_endpoint,site_id,access_token,source_folder_path):
    # SharePoint site ID or path
    site_id = site_id

    # Parent folder ID where the root folder will be created
    parent_folder_id = 'root'

    # Local source folder path
    source_folder_path = source_folder_path

    # Access token (obtained through authentication)

    # Copy folder structure to SharePoint
    copy_folder_structure_to_sharepoint(api_endpoint,site_id, parent_folder_id, source_folder_path, access_token)





##############

def get_drive_id(access_token,site_id):
    headers = {
      'Authorization': 'Bearer ' + access_token
    }
    conn = http.client.HTTPSConnection("graph.microsoft.com")
    payload = ''
    conn.request("GET", "/v1.0/sites/"+ site_id + "/drive/root/children/", payload, headers)
    res = conn.getresponse()
    data = res.read()
    data = json.loads(data)
    
    
    drive_id = data['value'][0]['id']
    return drive_id


def delete_previous_files(access_token,site_id,drive_id):
    
    conn = http.client.HTTPSConnection("graph.microsoft.com")
    payload = ''
    headers = {
      'Authorization': 'Bearer ' + access_token
    }
    conn.request("DELETE", "/v1.0/sites/" + site_id  + "/drive/items/" + drive_id , payload, headers)
    res = conn.getresponse()
    data = res.read()
    #print(data.decode("utf-8"))













