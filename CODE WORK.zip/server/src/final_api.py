# -*- coding: utf-8 -*-
"""
Created on Fri Jul 14 10:14:32 2023

@author: AZ318TQ
"""

import os
import base64
import logging
import colorlog
import pandas as pd
from functools import wraps
from http import HTTPStatus
from datetime import datetime
from my_logs import ColoredLogs
from flask import Flask, request,Blueprint
from app_logger import LogManager
from functions import Folder_creation
from config_manager import ConfigManager
from new_set import pushing_to_sharepoint,uploading
from input_push_update_delete_old_push_new import run_me
from utilities import getConfigValue,read_keys_from_our_excel
from flask import Flask, request, jsonify, Response, send_from_directory
import json 
import pandas as pd
from flask import Flask, request, jsonify,send_file
from keygenerator import check_timestamp_gap,generate_new_keys,generate_new_keys_desired_name

app = Flask(__name__)

api1_bp = Blueprint('api1', __name__)

log_file_path = os.path.join(getConfigValue("server", "applicationfolder")) + '\\'+ os.path.join(getConfigValue("server", "logs")) + '\\' 
logger = ColoredLogs(log_file_path + str(datetime.now()).split(' ')[0] +'_'+ str(datetime.now()).split(' ')[1].split(':')[0] + '_' + str(datetime.now()).split(' ')[1].split(':')[1]  +"_application.log")


def token_required(f):
    my_secret_keys = read_keys_from_our_excel()
    @wraps(f) 
    def decorator(*args, **kwargs):
        token = None
        if "x-access-token" in request.headers:
            token = request.headers["x-access-token"]
        if not token:
            return send_respone("A valid token is missing!", HTTPStatus.BAD_REQUEST)
        if token not in my_secret_keys:     # need to add a list token should be in this list! # getConfigValue("AccessToken"):
            return send_respone("Token is invalid!", HTTPStatus.INTERNAL_SERVER_ERROR)
        return f(*args, **kwargs)
    return decorator

def send_respone(msg, status):
    #return jsonify({"status": status, "msg": msg})
    return Response(response=msg, status=status)


@app.route('/api1/v1/',methods = ['GET'])
@token_required
def home():
    logger.log_info('Execution Started!')
    return "hello!"

@app.route('/api1/v1/uploadingfiles',methods = ['GET'])
@token_required
def test1():
    uploading()
    return "Done!"

@app.route('/api1/v1/pushtosharepoint',methods = ['GET'])
@token_required
def test2():
    pushing_to_sharepoint()
    return "Done!"


@app.route('/api1/v1/upload', methods=['POST'])
@token_required
def upload_file():
    try:
        base64_string = request.form.get('base64_string')
        filename = request.form.get('filename')

        if not base64_string or not filename:
            return 'Invalid request'

        # Decode base64 string to bytes
        file_data = base64.b64decode(base64_string)

        # Specify the folder path to save the file
        save_folder = getConfigValue('server','path')

        # Create the folder if it doesn't exist
        os.makedirs(save_folder, exist_ok=True)

        # Save the file in the folder
        with open(os.path.join(save_folder, filename), 'wb') as file:
            file.write(file_data)

        # files_list = Folder_creation()
        #print(files_list)

        return 'File saved successfully!' + filename  
    except Exception as e:
        return f'Error occurred: {str(e)}'


# second api for 
# app2 = Flask(__name__)
api2_bp = Blueprint('api2', __name__)

@app.route('/api2/v1/add_user', methods=['POST'])
def add_user():
    name = request.form.get('name')
    email = request.form.get('email')

    # Load the existing Excel file (assuming it already exists)
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)

    # Create a new DataFrame with the user data
    new_row = pd.DataFrame({'name': [name], 'email': [email]})

    # Concatenate the existing DataFrame with the new DataFrame
    df = pd.concat([df, new_row], ignore_index=True)

    # Save the updated DataFrame to the Excel file
    df.to_excel(excel_file, index=False)

    return jsonify({'message': 'User added successfully'})

@app.route('/api2/v1/key',methods=['GET'])
def keykey():
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)
    df = check_timestamp_gap(df)
    df.to_excel(excel_file, index=False)
    return ' doneeeeeeeee'

@app.route('/api2/v1/new_keys_for_all',methods=['GET'])
def newkeys():
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)
    df = generate_new_keys(df)
    df.to_excel(excel_file, index=False)
    return ' doneeeeeeeee'

@app.route('/api2/v1/new_key_for_req_user',methods=['GET'])
def newkeys_for_req_user():
    
    name = request.form.get('name')
    
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)
    df = generate_new_keys_desired_name(df,name)
    df.to_excel(excel_file, index=False)
    return ' doneeeeeeeee'

@app.route('/api2/v1/download_file', methods=['GET'])
def download_file():
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    return send_file(excel_file, as_attachment=True)


@app.route('/api2/v1/active_user', methods=['GET'])
def get_names():
    # Load the existing Excel file (assuming it already exists)
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)
    columns_to_convert = ['name', 'email']  # Specify the columns you want to convert
    subset_df = df[columns_to_convert] 
    data_list = json.loads(subset_df.to_json(orient='records'))
    # Get the list of all names from the DataFrame
    # names = df['name','email'].tolist()

    return jsonify({'names': data_list})

@app.route('/api2/v1/delete_user', methods=['POST'])
def delete_user():
    name = request.form.get('name')
    # Load the existing Excel file (assuming it already exists)
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)

    # Find the row(s) with the given name
    rows_to_delete = df[df['name'] == name].index

    # Delete the row(s) from the DataFrame
    df = df.drop(rows_to_delete)

    # Save the updated DataFrame to the Excel file
    df.to_excel(excel_file, index=False)

    return jsonify({'message': 'User deleted successfully'})

app.register_blueprint(api1_bp)
app.register_blueprint(api2_bp)



if __name__ =="__main__":
    # app.run(host = "0.0.0.0",port = "80")
    host = getConfigValue('server','apihost')
    port = int(getConfigValue('server','apiport'))
    app.run(host=host, port=port)
    
    # app1.run(port=5000,threaded=True)
    # app2.run(port=5001,threaded=True)
    # app1.run(host='0.0.0.0', port=5000, debug=False,threaded=True)
    # app2.run(host='0.0.0.1', port=5001, debug=False,threaded=True)






