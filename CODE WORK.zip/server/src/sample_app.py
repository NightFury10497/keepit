# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 15:22:36 2023

@author: AZ318TQ
"""
import json 
import pandas as pd
from flask import Flask, request, jsonify,send_file
from keygenerator import check_timestamp_gap,generate_new_keys,generate_new_keys_desired_name

app = Flask(__name__)


@app.route('/add_user', methods=['POST'])
def add_user():
    name = request.form.get('name')
    email = request.form.get('email')

    # Load the existing Excel file (assuming it already exists)
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)

    # Create a new DataFrame with the user data
    new_row = pd.DataFrame({'name': [name], 'email': [email]})

    # Concatenate the existing DataFrame with the new DataFrame
    df = pd.concat([df, new_row], ignore_index=True)

    # Save the updated DataFrame to the Excel file
    df.to_excel(excel_file, index=False)

    return jsonify({'message': 'User added successfully'})

@app.route('/key',methods=['GET'])
def keykey():
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)
    df = check_timestamp_gap(df)
    df.to_excel(excel_file, index=False)
    return ' doneeeeeeeee'

@app.route('/new_keys_for_all',methods=['GET'])
def newkeys():
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)
    df = generate_new_keys(df)
    df.to_excel(excel_file, index=False)
    return ' doneeeeeeeee'

@app.route('/new_key_for_req_user',methods=['GET'])
def newkeys_for_req_user():
    
    name = request.form.get('name')
    
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)
    df = generate_new_keys_desired_name(df,name)
    df.to_excel(excel_file, index=False)
    return ' doneeeeeeeee'

@app.route('/download_file', methods=['GET'])
def download_file():
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    return send_file(excel_file, as_attachment=True)


@app.route('/active_user', methods=['GET'])
def get_names():
    # Load the existing Excel file (assuming it already exists)
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)
    columns_to_convert = ['name', 'email']  # Specify the columns you want to convert
    subset_df = df[columns_to_convert] 
    data_list = json.loads(subset_df.to_json(orient='records'))


    # Get the list of all names from the DataFrame
    # names = df['name','email'].tolist()

    return jsonify({'names': data_list})

@app.route('/delete_user', methods=['POST'])
def delete_user():
    name = request.form.get('name')

    # Load the existing Excel file (assuming it already exists)
    excel_file = r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx'
    df = pd.read_excel(excel_file)

    # Find the row(s) with the given name
    rows_to_delete = df[df['name'] == name].index

    # Delete the row(s) from the DataFrame
    df = df.drop(rows_to_delete)

    # Save the updated DataFrame to the Excel file
    df.to_excel(excel_file, index=False)

    return jsonify({'message': 'User deleted successfully'})




if __name__ == '__main__':
    app.run(debug=True)
    
