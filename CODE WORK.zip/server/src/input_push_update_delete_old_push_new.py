# -*- coding: utf-8 -*-
"""
Created on Mon Jun 12 17:30:47 2023

@author: Automation.Finance
"""

import os
import json
import requests
import http.client
from uploader import check_dir,Folder_creation
from utilities import return_access_token,sharepoint_site_checker,download_previous_input_folder,download_temp_latest_uploaded_files,push_new_folder_to_sharepoint,get_drive_id,delete_previous_files

def run_me():
    # Generate Access Token
    access_token = return_access_token()
    
    # Checking for sharepoint site here 
    site_id = sharepoint_site_checker('InputSharepointAccess',access_token)
    
    #############################################################################################################
    #   download previous set of files from sharepoint 
    #############################################################################################################
    
    # Microsoft Graph API endpoint
    api_endpoint = 'https://graph.microsoft.com/v1.0'
    
    # temp folder location
    target_folder_path = r"C:\Users\fa.software\OneDrive - JX Nippon Two Lubricants India Pvt. Ltd2\old files\Desktop\Data\Temp"
    path = target_folder_path + '\Temp_Folder'
    
    # download previous folder strucutre which means the latest set of files (modified)
    download_previous_input_folder(api_endpoint,site_id,access_token,target_folder_path)
    
    
    ##############################################################################################################
    #               getting the latest uploaded files!
    #############################################################################################################
    
    # Generate a new Access Token
    access_token = return_access_token()
    
    
    # Checking for sharepoint site here 
    site_id = sharepoint_site_checker('TempFolderNewFilesAccessSharepoint',access_token)
    
    # Function to download a file from SharePoint
    download_temp_latest_uploaded_files(api_endpoint,site_id,access_token,path)
    
    
    ################################################################################################################
    # creation of updated input folder with new set of files!
    ################################################################################################################
    main_folder = 'Temp'
    inp = "Input_Folder"
    out = "Output_Folder"
    Folder_creation(main_folder,inp,out,path)
    
    ##################################################################################################################
    #    delete previous data from INPUT FOLDER from sharepoint to upload the latest set of INPUT FOLDER files
    ##################################################################################################################
    
    # Generate Access Token
    access_token = return_access_token()
    
    # Checking for sharepoint site here 
    site_id = sharepoint_site_checker('InputSharepointAccess',access_token)
    
    
    drive_id = get_drive_id(access_token,site_id)
    
    
    delete_previous_files(access_token,site_id,drive_id)
    
    
    
    #########################################################
    #       upload files back to sharepoint
    #########################################################
    # Generate Access Token
    access_token = return_access_token()
    
    # Checking for sharepoint site here 
    site_id = sharepoint_site_checker('InputSharepointAccess',access_token)
    
    
    source_folder_path = r"C:\Users\fa.software\OneDrive - JX Nippon Two Lubricants India Pvt. Ltd2\old files\Desktop\Data\Temp\Input_Folder"
    push_new_folder_to_sharepoint(api_endpoint,site_id,access_token, source_folder_path)
    
    
    
    
    
    ##################################################################################################################
    #    delete previous data from TEMP FOLDER from sharepoint to upload the latest set of INPUT FOLDER files
    ##################################################################################################################
    
    # Generate Access Token
    access_token = return_access_token()
    
    # Checking for sharepoint site here 
    site_id = sharepoint_site_checker('TempFolderNewFilesAccessSharepoint',access_token)
    
    
    drive_id = get_drive_id(access_token,site_id)
    
    
    delete_previous_files(access_token,site_id,drive_id)
    
    
    
    
    
    
    
    
    
    
    















