import pandas as pd
import hashlib
from datetime import datetime, timedelta
from flask import Flask, request, jsonify

app = Flask(__name__)

EXCEL_FILE = 'data.xlsx'
COLUMNS = ['name', 'email', 'key', 'timestamp']

@app.route('/add_user', methods=['POST'])
def add_user():
    name = request.form.get('name')
    email = request.form.get('email')
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    key = generate_key(name, email, timestamp)

    data = pd.DataFrame([[name, email, key, timestamp]], columns=COLUMNS)
    df = read_excel_file()
    df = pd.concat([df, data], ignore_index=True)

    df.to_excel(EXCEL_FILE, index=False)
    return jsonify({'message': 'User added successfully.'})

def generate_key(name, email, timestamp):
    data = name + email + timestamp
    key = hashlib.sha256(data.encode()).hexdigest()
    return key

def read_excel_file():
    df = pd.read_excel(EXCEL_FILE)
    return df

def update_keys():
    df = read_excel_file()
    current_time = datetime.now()
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    mask = df['timestamp'] < current_time - timedelta(days=28)
    df.loc[mask, 'timestamp'] = current_time
    df['key'] = df.apply(lambda row: generate_key(row['name'], row['email'], row['timestamp']), axis=1)
    df.to_excel(EXCEL_FILE, index=False)

if __name__ == '__main__':
    update_keys()  # Update keys on startup
    app.run(debug=True)
