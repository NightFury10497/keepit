# -*- coding: utf-8 -*-
"""
Created on Fri Jun 23 17:10:48 2023

@author: AZ318TQ
"""

import logging
from logging import StreamHandler
from logging.handlers import TimedRotatingFileHandler
import os
from utilities import getConfigValue


class ColoredFormatter(logging.Formatter):
    """Logging formatter that adds colors to the log levels."""

    RESET = "\033[0m"
    COLOR_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"

    COLORS = {
        logging.DEBUG: "\033[36m",    # Cyan
        logging.INFO: "\033[32m",     # Green
        logging.WARNING: "\033[33m",  # Yellow
        logging.ERROR: "\033[31m",    # Red
        logging.CRITICAL: "\033[35m", # Magenta
    }

    def format(self, record):
        log_level_color = self.COLORS.get(record.levelno, self.RESET)
        message = super().format(record)
        return f"{log_level_color}{message}{self.RESET}"


class MyLogg:
    log_file_path = os.path.join(getConfigValue("server", "applicationfolder")) + os.path.join(getConfigValue("server", "logs"))
    def __init__(self, log_file= log_file_path + '\app.log'):
        os.makedirs(os.path.dirname(log_file), exist_ok=True)

        self.logger = logging.getLogger('MyApp')
        self.logger.setLevel(logging.DEBUG)

        self.console_handler = StreamHandler()
        self.console_handler.setLevel(logging.DEBUG)

        self.file_handler = TimedRotatingFileHandler(log_file, when='midnight', backupCount=30, utc=True)
        self.file_handler.setLevel(logging.DEBUG)

        self.formatter = ColoredFormatter(ColoredFormatter.COLOR_FORMAT)
        self.console_handler.setFormatter(self.formatter)
        self.file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

        self.logger.addHandler(self.console_handler)
        self.logger.addHandler(self.file_handler)

    def log_info(self, message):
        self.logger.info(message)

    def log_error(self, message):
        self.logger.error(message)

    def log_warning(self, message):
        self.logger.warning(message)

    def log_debug(self, message):
        self.logger.debug(message)
