# -*- coding: utf-8 -*-
"""
Created on Fri Jun 23 12:44:51 2023

@author: AZ318TQ
"""

import logging
import os
import datetime

class LogManager:

    def __init__(self, log_file_path):
        self.log_file_path = log_file_path
        self._configure_logging()

    def _configure_logging(self):
        import logging
        import os
        import datetime
        if not os.path.exists(self.log_file_path):
            os.makedirs(self.log_file_path)

        now = datetime.datetime.now().strftime("%Y_%m_%d")
        log_file_name = f'{self.log_file_path}/HistoryLog_{now}.log'

        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(log_file_name),
            ]
        )

    def get_logger(self):
        return logging.getLogger()

if __name__ == '__main__':
    print('testing worked')