# -*- coding: utf-8 -*-
"""
Created on Mon Jun 26 15:04:37 2023

@author: AZ318TQ
"""
import os
from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/',methods = ['GET'])
def home():
    os.system(r"C:\Users\AZ318TQ\Anaconda3\python.exe  C:\Users\AZ318TQ\Documents\work\Eneos\server\src\my_test.py ")
    print("next step")
    return "hello!"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
    