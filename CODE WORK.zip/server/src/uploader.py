# -*- coding: utf-8 -*-
"""
Created on Mon Jun  5 15:49:52 2023

@author: AZ318TQ
"""

import os 
import shutil
# path = r"C:\Users\fa.software\OneDrive - JX Nippon Two Lubricants India Pvt. Ltd2\old files\Desktop\Data\Temp\Temp_Folder"



def check_dir(folder_path):
    if os.path.exists(folder_path):
        flag = 1
    else:
        os.mkdir(folder_path)
        flag = 2 
    return flag
        


def Folder_creation(main_folder,inp,out,path):
        for file in os.listdir(path):    
            print(file)
            if 'input' in str(file).lower():
                Input_F_P = f'{path}/{file}'
                folder_year = file.split('_')[1]
                folder_month = (file.split('_')[2]).split('.')[0]
                Input_folder_loc = ( f'{main_folder}/{inp}') # input_folder 
                Input_folder_year = ( f'{main_folder}/{inp}/{folder_year}')  # input_folder/2022
                Input_folder_Input_Files = ( f'{main_folder}/{inp}/{folder_year}/Input_Files')  #input_folder /2022/ input_files
            
                flag1 = check_dir(Input_folder_loc)
                flag2 = check_dir(Input_folder_year)
                flag3 = check_dir(Input_folder_Input_Files)
                
                if flag3 == 1:
                    # push files
                    # print(flag)
                    shutil.copy2(Input_F_P,Input_folder_Input_Files)
                elif flag3 == 2:
                    # create folder n then push files 
                    # print(flag)
                    shutil.copy2(Input_F_P,Input_folder_Input_Files)
            
            elif 'mapping' in str(file).lower():
                Mapping_F_P = f'{path}/{file}'
                Mapping_year = file.split('_')[1]
                Mapping_month = (file.split('_')[2]).split('.')[0]
                Mapping_folder_loc = ( f'{main_folder}/{inp}') # input_folder 
                Mapping_folder_year = ( f'{main_folder}/{inp}/{Mapping_year}')  # input_folder/2022
                Mapping_folder_Input_Files = ( f'{main_folder}/{inp}/{Mapping_year}')  #input_folder /2022/ input_files
            
                flag1 = check_dir(Mapping_folder_loc)
                flag2 = check_dir(Mapping_folder_year)
                flag3 = check_dir(Mapping_folder_Input_Files)
                
                if flag3 == 1:
                    # push files
                    # print(flag)
                    shutil.copy2(Mapping_F_P,Mapping_folder_Input_Files)
                elif flag3 == 2:
                    # create folder n then push files 
                    # print(flag)
                    shutil.copy2(Mapping_F_P,Mapping_folder_Input_Files)
            
            elif 'budget' in str(file).lower():
                budget_F_P = f'{path}/{file}'
                budget_year = file.split('_')[1]
                budget_month = (file.split('_')[2]).split('.')[0]
                budget_folder_loc = ( f'{main_folder}/{inp}') # input_folder 
                budget_folder_year = ( f'{main_folder}/{inp}/{budget_year}')  # input_folder/2022
                budget_folder_Input_Files = ( f'{main_folder}/{inp}/{budget_year}')  #input_folder /2022/ input_files
            
                flag1 = check_dir(budget_folder_loc)
                flag2 = check_dir(budget_folder_year)
                flag3 = check_dir(budget_folder_Input_Files)
                
                if flag3 == 1:
                    # push files
                    # print(flag)
                    shutil.copy2(budget_F_P,budget_folder_Input_Files)
                elif flag3 == 2:
                    # create folder n then push files 
                    # print(flag)
                    shutil.copy2(budget_F_P,budget_folder_Input_Files)
            
            
            # file = 'tally_2022_apr.xlsx'
            elif 'tally' in str(file).lower():
                tally_F_P = f'{path}/{file}'
                tally_year = file.split('_')[1]
                tally_month = (file.split('_')[2]).split('.')[0]
                tally_folder_loc = ( f'{main_folder}/{inp}') # input_folder 
                tally_folder_year = ( f'{main_folder}/{inp}/{tally_year}')  # input_folder/2022
                tally_folder_Input_Files = ( f'{main_folder}/{inp}/{tally_year}/Tally_Files')  #input_folder /2022/ input_files
            
                flag1 = check_dir(tally_folder_loc)
                flag2 = check_dir(tally_folder_year)
                flag3 = check_dir(tally_folder_Input_Files)
                
                if flag3 == 1:
                    # push files
                    # print(flag)
                    shutil.copy2(tally_F_P,tally_folder_Input_Files)
                elif flag3 == 2:
                    # create folder n then push files 
                    # print(flag)
                    shutil.copy2(tally_F_P,tally_folder_Input_Files)
            
            Output_folder_loc = ( f'{main_folder}/{out}')    
            Output_F_P = f'{path}/{file}'
            folder_year = file.split('_')[1]
            folder_month = (file.split('_')[2]).split('.')[0]
            Input_folder_loc = ( f'{main_folder}/{inp}') # input_folder 
            Input_folder_year = ( f'{main_folder}/{inp}/{folder_year}')  # input_folder/2022
            Input_folder_Input_Files = ( f'{main_folder}/{inp}/{folder_year}/Input_Files')  #input_folder /2022/ input_files

            Output_folder_loc = ( f'{main_folder}/{out}')
            if not os.path.exists(Output_folder_loc):
                os.mkdir(Output_folder_loc)
            
            Output_year_folder = ( f'{main_folder}/{out}/{folder_year}')
            if not os.path.exists(Output_year_folder):
                os.mkdir(Output_year_folder)
                
            Output_files_folder = ( f'{main_folder}/{out}/{folder_year}/{folder_month}')
            if not os.path.exists(Output_files_folder):
                os.mkdir(Output_files_folder)



            
            
        else:
            print('file does not exist')
            
        
            
            
            
            
            
    
# path_input_ = r"C:\Users\AZ318TQ\OneDrive - EY\Backup\Documents\work\eneos\tejas files\New folder\ENEOS (2)\ENEOS\Code\Output1 code\me\Temp\\" + inp        

# list_of_year = os.listdir(path_input_)
# list_of_ = os.listdir(path_input_ +'/'+ list_of_year[0])




# def run_code(input_file,mapping_file,budget_file,tally_file):
#     print('code executed')
    
    


    









