# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 15:09:09 2023

@author: AZ318TQ
"""

import pandas as pd
import hashlib
from datetime import datetime, timedelta

def generate_key(name, email, timestamp):
    # Concatenate name, email, and timestamp
    data = name + email + str(timestamp)

    # Generate SHA-256 hash
    sha256_hash = hashlib.sha256(data.encode()).hexdigest()
    return sha256_hash

def check_timestamp_gap(df):
    # Get the current timestamp
    current_time = datetime.now()

    # Iterate over each row in the dataframe
    for index, row in df.iterrows():
        timestamp = row['Timestamp']
        generated_key = row['Generated key']
        
        # Check if the timestamp is missing or has a gap of more than 28 days
        if pd.isnull(timestamp) or current_time - timestamp >= timedelta(days=28):
            # Generate a new key
            name = row['name']
            email = row['email']
            new_key = generate_key(name, email, current_time)

            # Update the key and timestamp for the record
            df.at[index, 'Generated key'] = new_key
            df.at[index, 'Timestamp'] = current_time

    return df

def generate_new_keys(df):
    # Get the current timestamp
    current_time = datetime.now()

    # Iterate over each row in the dataframe
    for index, row in df.iterrows():
        name = row['name']
        email = row['email']
        # row['timestamp']
        # Generate a new key using the current timestamp
        new_key = generate_key(name, email, current_time)

        # Update the key for the record
        df.at[index, 'Generated key'] = new_key
        df.at[index, 'Timestamp'] = current_time

    return df

def generate_new_keys_desired_name(df, name):
    # Get the current timestamp
    current_time = datetime.now()

    # Iterate over each row in the dataframe
    for index, row in df.iterrows():
        if row['name'] == name:
            email = row['email']
            # Generate a new key using the current timestamp
            new_key = generate_key(name, email, current_time)

            # Update the key for the record
            df.at[index, 'Generated key'] = new_key
            df.at[index, 'Timestamp'] = current_time

    return df




# Read the Excel file
df = pd.read_excel(r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx')

# Call the function to check and update the timestamp and key if needed
df = check_timestamp_gap(df)

# Save the updated dataframe to a new Excel file
df.to_excel(r'C:\Users\AZ318TQ\Documents\work\Eneos\server\Config\data.xlsx', index=False)
