# -*- coding: utf-8 -*-
"""
Created on Wed Jun 14 13:44:27 2023

@author: Automation.Finance
"""

import os
import base64
import logging
import colorlog
import pandas as pd
from flask import Flask, request
from app_logger import LogManager
from utilities import getConfigValue,read_keys_from_our_excel
from functions import Folder_creation
from functools import wraps
from config_manager import ConfigManager
from new_set import pushing_to_sharepoint,uploading
from input_push_update_delete_old_push_new import run_me
from datetime import datetime
from flask import Flask, request, jsonify, Response, send_from_directory
from http import HTTPStatus


app = Flask(__name__)

from my_logs import ColoredLogs

log_file_path = os.path.join(getConfigValue("server", "applicationfolder")) + '\\'+ os.path.join(getConfigValue("server", "logs")) + '\\' 
logger = ColoredLogs(log_file_path + str(datetime.now()).split(' ')[0] +'_'+ str(datetime.now()).split(' ')[1].split(':')[0] + '_' + str(datetime.now()).split(' ')[1].split(':')[1]  +"_application.log")

def token_required(f):
    my_secret_keys = read_keys_from_our_excel()
    @wraps(f) 
    def decorator(*args, **kwargs):
        token = None
        if "x-access-token" in request.headers:
            token = request.headers["x-access-token"]
        if not token:
            return send_respone("A valid token is missing!", HTTPStatus.BAD_REQUEST)
        if token not in my_secret_keys:     # need to add a list token should be in this list! # getConfigValue("AccessToken"):
            return send_respone("Token is invalid!", HTTPStatus.INTERNAL_SERVER_ERROR)
        return f(*args, **kwargs)
    return decorator

def send_respone(msg, status):
    #return jsonify({"status": status, "msg": msg})
    return Response(response=msg, status=status)


@app.route('/api/v1/',methods = ['GET'])
@token_required
def home():
    logger.log_info('Execution Started!')
    return "hello!"


@app.route('/api/v1/uploadingfiles',methods = ['GET'])
@token_required
def test1():
    uploading()
    return "Done!"

@app.route('/api/v1/pushtosharepoint',methods = ['GET'])
@token_required
def test2():
    pushing_to_sharepoint()
    return "Done!"


@app.route('/api/v1/upload', methods=['POST'])
@token_required
def upload_file():
    try:
        base64_string = request.form.get('base64_string')
        filename = request.form.get('filename')

        if not base64_string or not filename:
            return 'Invalid request'

        # Decode base64 string to bytes
        file_data = base64.b64decode(base64_string)

        # Specify the folder path to save the file
        save_folder = getConfigValue('server','path')

        # Create the folder if it doesn't exist
        os.makedirs(save_folder, exist_ok=True)

        # Save the file in the folder
        with open(os.path.join(save_folder, filename), 'wb') as file:
            file.write(file_data)

        # files_list = Folder_creation()
        #print(files_list)

        return 'File saved successfully!' + filename  
    except Exception as e:
        return f'Error occurred: {str(e)}'



if __name__ =="__main__":
    # app.run(host = "0.0.0.0",port = "80")
    host = getConfigValue('server','apihost')
    port = int(getConfigValue('server','apiport'))
    app.run(host=host, port=port, debug=False)
    


