# -*- coding: utf-8 -*-
"""
Created on Wed May 31 11:56:58 2023

@author: Automation.Finance
"""

# Required Packages
import pandas as pd
from dateutil import relativedelta
import calendar
import datetime
import numpy as np
from openpyxl import load_workbook
import configparser
import re
import xlsxwriter
import xlwings as xw
import os
import shutil

inp = "Input_Folder"
out = "Output_Folder"


def Folder_creation():
    path = '/home/batra/flaskapplication/Temp/Temp_Folder/'
    
    
    if len(os.listdir(path))==1:
        for file in os.listdir(path):
            # print(i)
            if 'INPUT' in file:
                Input_F_P = f'{path}/{file}'
                folder_year = file.split('_')[1]
                folder_month = file.split('_')[2]
                folder_month = folder_month.split('.')[0]
                main_folder = 'Temp'
                inp = "Input_Folder"
                out = "Output_Folder"
        
        # Input files folder creation
        
                Input_folder_loc = ( f'{main_folder}/{inp}')
                if not os.path.exists(Input_folder_loc):
                    os.mkdir(Input_folder_loc)
                
                Input_year_folder = ( f'{main_folder}/{inp}/{folder_year}')
                if not os.path.exists(Input_year_folder):
                    os.mkdir(Input_year_folder)
                    
                Input_files_folder = ( f'{main_folder}/{inp}/{folder_year}/Input_Files')
                if not os.path.exists(Input_files_folder):
                    os.mkdir(Input_files_folder)
                
                # Output files folder creation
                
                Output_folder_loc = ( f'{main_folder}/{out}')
                if not os.path.exists(Output_folder_loc):
                    os.mkdir(Output_folder_loc)
                
                Output_year_folder = ( f'{main_folder}/{out}/{folder_year}')
                if not os.path.exists(Output_year_folder):
                    os.mkdir(Output_year_folder)
                    
                Output_files_folder = ( f'{main_folder}/{out}/{folder_year}/{folder_month}')
                if not os.path.exists(Output_files_folder):
                    os.mkdir(Output_files_folder)

                # copying files to respective folder.
                
                # copying Input files to Input files folder.
                shutil.copy2(Input_F_P, Input_files_folder)
                
                other_file_list = []
                for files in os.listdir(Input_year_folder):
                    if 'Input' not in files:
                        file_append = f'{Input_year_folder}/{files}'
                        other_file_list.append(file_append)
                
                Input_file_list = []
                for files in os.listdir(Input_files_folder):
                    file_append = f'{Input_files_folder}/{files}'
                    Input_file_list.append(file_append)
                    
                empty_dict = {}
                
                empty_dict['other_files'] = other_file_list
                
                empty_dict['Input_files'] = Input_file_list
                
                empty_dict['Output_file_loc'] = Output_files_folder
                
                return empty_dict
            else:
                print('Place Input file.')
    elif len(os.listdir(path))>1:
        inp = "Input_Folder"
        out = "Output_Folder"
        Budget_F_P =""
        Mapping_F_P = ""
        Tally_F_P = ""
        for file in os.listdir(path):
            # print(i)
            if 'INPUT' in file:
                Input_F_P = f'{path}/{file}'
                folder_year = file.split('_')[1]
                folder_month = file.split('_')[2]
                folder_month = folder_month.split('.')[0]
            elif 'BUDGET' in file:
                Budget_F_P = f'{path}/{file}'
            elif 'MAPPING' in file:
                Mapping_F_P = f'{path}/{file}'
            elif 'TALLY' in file:
                Tally_F_P = f'{path}/{file}'
        main_folder = 'Temp'
        
        # Input files folder creation
        
        Input_folder_loc = ( f'{main_folder}/{inp}')
        if not os.path.exists(Input_folder_loc):
            os.mkdir(Input_folder_loc)
        
        Input_year_folder = ( f'{main_folder}/{inp}/{folder_year}')
        if not os.path.exists(Input_year_folder):
            os.mkdir(Input_year_folder)
            
        Input_files_folder = ( f'{main_folder}/{inp}/{folder_year}/Input_Files')
        if not os.path.exists(Input_files_folder):
            os.mkdir(Input_files_folder)
        
        # Output files folder creation
        
        Output_folder_loc = ( f'{main_folder}/{out}')
        if not os.path.exists(Output_folder_loc):
            os.mkdir(Output_folder_loc)
        
        Output_year_folder = ( f'{main_folder}/{out}/{folder_year}')
        if not os.path.exists(Output_year_folder):
            os.mkdir(Output_year_folder)
            
        Output_files_folder = ( f'{main_folder}/{out}/{folder_year}/{folder_month}')
        if not os.path.exists(Output_files_folder):
            os.mkdir(Output_files_folder)
        
        
        # copying files to respective folder.
        
        # copying Input files to Input files folder.
        shutil.copy2(Input_F_P, Input_files_folder)
        
        # copying other than Input files to year folder.
        shutil.copy2(Budget_F_P, Input_year_folder)
        
        shutil.copy2(Mapping_F_P, Input_year_folder)
        
        shutil.copy2(Tally_F_P, Input_year_folder)
        
        other_file_list = []
        for files in os.listdir(Input_year_folder):
            if 'Input' not in files:
                file_append = f'{Input_year_folder}/{files}'
                other_file_list.append(file_append)
        
        Input_file_list = []
        for files in os.listdir(Input_files_folder):
            file_append = f'{Input_files_folder}/{files}'
            Input_file_list.append(file_append)
            
        empty_dict = {}
        
        empty_dict['other_files'] = other_file_list
        
        empty_dict['Input_files'] = Input_file_list
        
        empty_dict['Output_file_loc'] = Output_files_folder
        
        # empty_dict['year'] = folder_year
        
        return empty_dict
    else:
        print('No file is present in the given directory')
        
        
          
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
