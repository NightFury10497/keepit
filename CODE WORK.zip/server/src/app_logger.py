# -*- coding: utf-8 -*-
"""
Created on Thu Jun 22 16:42:41 2023

@author: AZ318TQ
"""

import logging
import logging.config
import yaml
import os
import datetime
# from threading import Lock
import colorlog

# class LogManagerMeta(type):
#     """
#     This is a thread-safe implementation of Singleton.
#     """

#     _instances = {}

#     _lock: Lock = Lock()
#     """
#     We now have a lock object that will be used to synchronize threads during
#     first access to the Singleton.
#     """

#     def __call__(cls, *args, **kwargs):
#         """
#         Possible changes to the value of the `__init__` argument do not affect
#         the returned instance.
#         """
#         # Now, imagine that the program has just been launched. Since there's no
#         # Singleton instance yet, multiple threads can simultaneously pass the
#         # previous conditional and reach this point almost at the same time. The
#         # first of them will acquire lock and will proceed further, while the
#         # rest will wait here.
#         with cls._lock:
#             # The first thread to acquire the lock, reaches this conditional,
#             # goes inside and creates the Singleton instance. Once it leaves the
#             # lock block, a thread that might have been waiting for the lock
#             # release may then enter this section. But since the Singleton field
#             # is already initialized, the thread won't create a new object.
#             if cls not in cls._instances:
#                 instance = super().__call__(*args, **kwargs)
#                 cls._instances[cls] = instance
#         return cls._instances[cls]

class LogManager: #(metaclass=LogManagerMeta):
    _logFilePath: str = None
    
    def __init__(self, logFilePath) -> None:
        self._logFilePath = logFilePath
        if not os.path.exists(self._logFilePath):
            os.makedirs(self._logFilePath)
        
        now = datetime.datetime.now().strftime("%Y_%m_%d")
        dynamic_log_name = f'{self._logFilePath}\HistoryLog_{now}.log'
        configString = "version: 1\n"\
                           "formatters:\n"\
                           "  simple:\n"\
                           "    format: '%(asctime)s - %(levelname)s - %(message)s'\n"\
                           "  colored:\n"\
                           "    format: '%(log_color)s%(asctime)s%(reset)s - %(log_color)s%(levelname)s%(reset)s - %(log_color)s%(message)s%(reset)s'\n"\
                           "    class: colorlog.ColoredFormatter\n"\
                           "handlers:\n"\
                           "  console:\n"\
                           "    class: logging.StreamHandler\n"\
                           "    level: DEBUG\n"\
                           "    formatter: colored\n"\
                           "    stream: ext://sys.stdout\n"\
                           "  file:\n"\
                           "    class : logging.handlers.RotatingFileHandler\n"\
                           "    formatter: simple\n"\
                           f"    filename: {dynamic_log_name}\n"\
                           "    maxBytes: 10485760\n"\
                           "    backupCount: 3\n"\
                           "loggers:\n"\
                           "  sampleLogger:\n"\
                           "    level: DEBUG\n"\
                           "    handlers: [console]\n"\
                           "    propagate: no\n"\
                           "  fileLogger:\n"\
                           "    level: DEBUG\n"\
                           "    handlers: [file]\n"\
                           "root:\n"\
                           "  level: DEBUG\n"\
                           "  handlers: [console]"
                           
        config = yaml.safe_load(configString)
        logging.config.dictConfig(config)
        self.__logger = {"fileLogger": logging.getLogger('fileLogger'), "sampleLogger": logging.getLogger('sampleLogger')}
        
    def get_logger(self, logger = "sampleLogger"):
        return self.__logger[logger]


if __name__ == '__main__':
    print(getApplicationPath())