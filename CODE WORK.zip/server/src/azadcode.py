# -*- coding: utf-8 -*-
"""
Created on Wed Jun 21 10:59:51 2023

@author: Automation.Finance
"""


client_id  = "840bc398-98e6-46ff-a729-1b912550d557"

client_secret  = "B.C8Q~B0X-rhgShheuhTi6Onk7R.JMHCxxCAaa4X"

tenant_id  = "dd655549-a56d-485e-b09c-a5eb11419b79"

from flask import Flask, redirect, url_for, request, session
from flask_oauthlib.client import OAuth
import requests

app = Flask(__name__)
app.config['SECRET_KEY'] = client_secret
app.config['OAUTH_CREDENTIALS'] = {
    'azuread': {
        'id': client_id,
        'secret': client_secret,
    }
}

oauth = OAuth(app)
azuread = oauth.remote_app(
    'azuread',
    consumer_key=app.config['OAUTH_CREDENTIALS']['azuread']['id'],
    consumer_secret=app.config['OAUTH_CREDENTIALS']['azuread']['secret'],
    request_token_params={'scope': 'openid email profile'},
    base_url='https://login.microsoftonline.com/' + tenant_id + '/',
    request_token_url=None,
    access_token_method='POST',
    access_token_url='https://login.microsoftonline.com/' + tenant_id + '/oauth2/token',
    authorize_url='https://login.microsoftonline.com/' + tenant_id + '/oauth2/authorize'
)

@app.route('/login')
def login():
    return azuread.authorize(callback=url_for('authorized', _external=True))

@app.route('/login/authorized')
def authorized():
    resp = azuread.authorized_response()
    print('printing respresprespresp',resp)
    if resp is None:
        return 'Access denied: reason={0} error={1}'.format(
            request.args['error_reason'],
            request.args['error_description']
        )
    if isinstance(resp):
        return 'Access denied: {0}'.format(resp.message)

    # Store the access token and perform additional authentication if needed
    access_token = resp['access_token']
    session['azuread_token'] = (access_token, '')
    
    # Perform any additional authentication logic and return a response

@azuread.tokengetter
def get_azuread_token():
    return session.get('azuread_token')

if __name__ == '__main__':
    app.run(host = "0.0.0.0",port = 5000)
